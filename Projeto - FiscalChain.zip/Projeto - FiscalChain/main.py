import streamlit as st
import time
# Design da barra lateral esquerda
logomarca = "logomarca_grupo268.png"
st.logo(logomarca, size = "large", link = "https://colab.research.google.com/drive/1I_6p4mzmOWMAfbsobJF_Je-jsr-eSqe6?usp=sharing", icon_image = logomarca)
st.sidebar.image(logomarca,caption='Grupo 268 - Agentes Autônomos com IA Generativa', width = None, clamp=False, channels="RGB", output_format="auto", use_container_width=True)
st.sidebar.markdown("<h2 style='text-align: center;'>Integrantes do Grupo:</h2>", unsafe_allow_html=True)
st.sidebar.markdown(
    """
    <div style="text-align: center;">
        Guilherme<br>
        Laion<br>
        José<br>
        Samilla<br>
        Luciana<br>
        Pedro<br>
        André<br>
        Israel<br>
        Felipe
    </div>
    """,
    unsafe_allow_html=True
)
#Design da página principal
st.title("📊 FiscalChain"
st.write("Agente Inteligente para Análise de Documentos Fiscais")
st.divider()
with st.chat_message("ai"):
    st.write("Olá humano!")
    st.write("Sou a FiscalChain, a sua assistente inteligente.")
    st.write("Para começar, anexa o documento fiscal para que eu possa validá-lo")
    
arquivo = st.file_uploader("Instale o arquivo")



#prompt = st.chat_input("Pergunte alguma coisa")



